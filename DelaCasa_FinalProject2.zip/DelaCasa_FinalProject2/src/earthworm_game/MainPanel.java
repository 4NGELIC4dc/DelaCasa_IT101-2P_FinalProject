package earthworm_game;
import java.awt.*;
import java.awt.event.*;
import javax.sound.sampled.*;
import javax.swing.*;
import java.util.Random;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
public class MainPanel extends JPanel implements ActionListener, KeyListener {
	private Clip bgAudio;
	private Clip bgEat;
	static final int SCREEN_WIDTH = 600, SCREEN_HEIGHT = 600, UNIT_SIZE = 20, DELAY = 60;
	static final int GAME_UNITS = (SCREEN_WIDTH*SCREEN_HEIGHT)/UNIT_SIZE;
	final int x[] = new int[GAME_UNITS];
	final int y[] = new int[GAME_UNITS];
	int snakeBody = 5, foodPoint = 0, foodX, foodY;
	char direction = 'D';
	boolean running = false;
	String title = "EarthWorm";
	Timer timer;
	Random random;
	FileWriter fwrite;
	ArrayList<LeaderBoard> leaderboard = new ArrayList<>();
	MainPanel(){
		random = new Random();
		leaderboard=new ArrayList<>();
		this.setPreferredSize(new Dimension(SCREEN_WIDTH,SCREEN_HEIGHT));
		this.setBackground(new Color(43,44,90));
		this.setFocusable(true);
		this.addKeyListener(new MyKeyAdapter());
		gameStart();
	}
	public void audioLoad() {
		try {
			AudioInputStream bgAudioStream = AudioSystem.getAudioInputStream(new File("audios/game_bgsound2.wav"));
            AudioInputStream bgEatStream = AudioSystem.getAudioInputStream(new File("audios/game_sfx2.wav"));
            bgAudio = AudioSystem.getClip();
            bgEat = AudioSystem.getClip();
            bgAudio.open(bgAudioStream);
            bgEat.open(bgEatStream);
		} catch(UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
	}
	public void playBgAudio() {
		 if (bgAudio != null && !bgAudio.isRunning()) {
	            bgAudio.loop(Clip.LOOP_CONTINUOUSLY);
	      }
	}
	public void playBgEat() {
		 if (bgEat != null) {
	            bgEat.stop();
	            bgEat.setFramePosition(0);
	            bgEat.start();
	      }
	}
	public void gameStart() {
		newPoint();
		running = true;
		timer = new Timer(DELAY, this);
		timer.start();
		audioLoad();
		playBgAudio();
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		ImageIcon background=new ImageIcon("images/game_bg4.png");
		g.drawImage(background.getImage(),0,0,this.getWidth(),this.getHeight(),null);
		draw(g);
	}
	public void draw(Graphics g) {
		if(running) {
		g.setColor(new Color(random.nextInt(255),random.nextInt(255),random.nextInt(255)));
		g.fillOval(foodX, foodY, UNIT_SIZE, UNIT_SIZE);
		for(int i = 0; i<snakeBody;i++) {
			if(i==0) {
				g.setColor(new Color(202, 52, 51));
				g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
			} else {
				g.setColor(new Color(150, 0, 24));
				g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
				}
			}
		g.setColor(Color.white);
		g.setFont(new Font("Courier",Font.BOLD,20));
		FontMetrics metrics = getFontMetrics(g.getFont());
		g.drawString("SCORE: "+foodPoint, (SCREEN_WIDTH - metrics.stringWidth("SCORE: "+foodPoint))/2, g.getFont().getSize());
		} else {
			gameOver(g);
		}
	}
	public void move() {
		for(int i = snakeBody;i>0;i--) {
			x[i] = x[i-1];
			y[i] = y[i-1];
		}
		switch(direction) {
		case 'U':
			y[0]=y[0] - UNIT_SIZE;
			break;
		case 'D':
			y[0]=y[0] + UNIT_SIZE;
			break;
		case 'L':
			x[0]=x[0] - UNIT_SIZE;
			break;
		case 'R':
			x[0]=x[0] + UNIT_SIZE;
			break;
		}
	}
	public void newPoint() {
		foodX = random.nextInt((int)(SCREEN_WIDTH/UNIT_SIZE))*UNIT_SIZE;
		foodY = random.nextInt((int)(SCREEN_WIDTH/UNIT_SIZE))*UNIT_SIZE;
	}
	public void objPoint() {
		if((x[0]==foodX)&&(y[0]==foodY)) {
			snakeBody++;
			foodPoint++;
			newPoint();
			playBgEat();
		}
	}
	public void objCollide() {
		for(int i = snakeBody;i>0;i--) {
			if((x[0] == x[i]) && (y[0] == y[i])) {
				running = false;
			}
		}
		if(x[0]<0) {
			running = false;
		}
		if(x[0]>SCREEN_WIDTH) {
			running = false;
		}
		if(y[0]<0) {
			running = false;
		}
		if(y[0]>SCREEN_HEIGHT) {
			running = false;
		}
		if(!running) {
			timer.stop();
		}
	}
	public void gameOver(Graphics g) {
		g.setColor(Color.white);
		g.setFont(new Font("Courier",Font.BOLD,20));
		FontMetrics metrics1 = getFontMetrics(g.getFont());
		g.drawString("SCORE: "+foodPoint, (SCREEN_WIDTH - metrics1.stringWidth("SCORE: "+foodPoint))/2, g.getFont().getSize());
		
		g.setColor(new Color(202, 52, 51));
		g.setFont(new Font("Cooper Black",Font.BOLD,80));
		FontMetrics metrics2 = getFontMetrics(g.getFont());
		g.drawString("GAME OVER", (SCREEN_WIDTH - metrics2.stringWidth("GAME OVER"))/2, SCREEN_HEIGHT/2);
		
		g.setColor(Color.white);
		g.setFont(new Font("Cooper Black", Font.BOLD,20));
		FontMetrics metrics3 = getFontMetrics(g.getFont());
		g.drawString("Press [SPACE] to restart the game.", (SCREEN_WIDTH - metrics3.stringWidth("Press [SPACE] to restart the game."))/2, 350);
		
		if (bgAudio != null && bgAudio.isRunning()) {
	        bgAudio.stop();
	    }
		try {
			JFrame inputFrame = new JFrame("EarthWorm");
		    JTextField textField = new JTextField();
		    textField.setPreferredSize(new Dimension(200, 30));
		    JButton submitButton = new JButton("Enter");
		    submitButton.addActionListener(new ActionListener() {
		        @Override
		        public void actionPerformed(ActionEvent e) {
		            String name = textField.getText();
		            leaderboard.add(new LeaderBoard(name, foodPoint));
		            writeLeaderboard();
		            inputFrame.dispose();
		            showLeaderboard();
		        }
		    });
		    JPanel inputPanel = new JPanel();
		    inputPanel.add(new JLabel("Enter your name: "));
		    inputPanel.add(textField);
		    inputPanel.add(submitButton);
		    inputFrame.setContentPane(inputPanel);
		    inputFrame.pack();
		    inputFrame.setLocationRelativeTo(null);
		    inputFrame.setVisible(true);
		} catch (Exception e) {
			// TODO: handle exception
		} 	
	}
	public void showLeaderboard() {
		JFrame leaderboardFrame = new JFrame("EarthWorm LEADERBOARD");
		leaderboardFrame.setSize(300, 600);
        leaderboardFrame.setLocationRelativeTo(null);
		leaderboardFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JTextArea leaderboardTextArea = new JTextArea();
        leaderboardTextArea.setEditable(false);
        leaderboardTextArea.setFont(new Font("Courier", Font.BOLD, 15));
        leaderboardTextArea.setForeground(new Color(132,192, 17));
        try (Scanner scanner = new Scanner(new File("Score.txt"))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                leaderboardTextArea.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        leaderboardFrame.getContentPane().add(new JScrollPane(leaderboardTextArea));
        leaderboardFrame.setVisible(true);
	}
	public void writeLeaderboard() {
		try {
			FileWriter writer=new FileWriter("Score.txt",true);
			for (LeaderBoard entry:leaderboard) {
				writer.write(entry.getName() + "	" + entry.getScore() + "\n");
			}
			writer.close();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void gameRestart() {
		setVisible(false);
		new MainFrame();
	}
	public void dispose() {
		JFrame parent = (JFrame) this.getTopLevelAncestor();
		parent.dispose();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(running) {
			move();
			objPoint();
			objCollide();
		}
		repaint();
	}
	public class MyKeyAdapter extends KeyAdapter{
		@Override
		public void keyPressed(KeyEvent e) {
			switch(e.getKeyCode()) {
			case KeyEvent.VK_A:
				if(direction != 'R') {
					direction = 'L';
				}
				break;
			case KeyEvent.VK_D:
				if(direction != 'L') {
					direction = 'R';
				}
				break;
			case KeyEvent.VK_W:
				if(direction != 'D') {
					direction = 'U';
				}
				break;
			case KeyEvent.VK_S:
				if(direction != 'U') {
					direction = 'D';
				}
				break;
			case KeyEvent.VK_LEFT:
				if(direction != 'R') {
					direction = 'L';
				}
				break;
			case KeyEvent.VK_RIGHT:
				if(direction != 'L') {
					direction = 'R';
				}
				break;
			case KeyEvent.VK_UP:
				if(direction != 'D') {
					direction = 'U';
				}
				break;
			case KeyEvent.VK_DOWN:
				if(direction != 'U') {
					direction = 'D';
				}
				break;
			case KeyEvent.VK_SPACE:
				gameRestart();
				break;
			}
		}
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	}
}