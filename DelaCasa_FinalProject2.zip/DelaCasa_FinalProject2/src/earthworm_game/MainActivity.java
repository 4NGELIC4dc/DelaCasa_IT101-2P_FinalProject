package earthworm_game;
public class MainActivity{
	public static void main (String[]args) {
		new MainFrame();
	}
}