package earthworm_game;
import java.util.*;
public class LeaderBoard {
	private String playerName;
	private int score;
	public LeaderBoard(String playerName, int score) {
		this.playerName=playerName;
		this.score=score;
	}
	public String getName() {
		return playerName;
	}
	public int getScore() {
		return score;
	}
}