package earthworm_game;
import javax.swing.JFrame;
public class MainFrame extends JFrame{
	MainFrame(){
		this.add(new MainPanel());
		this.setTitle("EarthWorm");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.pack();
		this.setVisible(true);
		this.setLocationRelativeTo(null);
	}
}